/* =========================================================
    include.js
    - 각 페이지에서 공통으로 사용하는 헤더(header.html),
      상단 메뉴(menu.html), 푸터(footer.html)를 자동으로 삽입하고,
    - 현재 활성화된 상단 메뉴에 따라
      1) 왼쪽 사이드 메뉴  : menu-XXX.html
      2) 본문 내용         : content-XXX.html
        을 자동으로 불러와 넣어주는 자바스크립트 파일입니다.
   ========================================================= */


/* =========================================================
  1. DOMContentLoaded 이벤트
  ---------------------------------------------------------
    - HTML 문서의 기본 구조(태그)가 모두 로딩되면 실행됩니다.
    - 이미지, 폰트가 다 불러와질 때까지 기다릴 필요 없이,
      태그 구조만 준비되면 바로 실행되는 시점입니다.
   ========================================================= */
document.addEventListener("DOMContentLoaded", () => {
  // =============== 1️⃣ 헤더(header.html) 불러오기 ===============

  /*
    fetch("header.html")
      - 서버(또는 로컬)에 있는 header.html 파일을 요청해서 가져옵니다.
      - 가져온 결과(res)를 .text() 로 호출하면,
        HTML 코드가 문자열 형태로 넘어옵니다.
  */
  fetch("header.html")
    .then((res) => res.text())
    .then((html) => {
      /*
        #header-slot 요소 찾기
          - index.html 에 있는 <div id="header-slot"></div> 를 의미합니다.
      */
      const slot = document.querySelector("#header-slot");

      /*
        slot.insertAdjacentHTML("afterend", html)
          - #header-slot 태그 바로 "뒤(afterend)"에
            header.html 의 내용을 실제 HTML로 삽입합니다.
          - 이렇게 하면 header.html 이 모든 페이지 상단에 공통으로 들어가게 됩니다.
      */
      if (slot) slot.insertAdjacentHTML("afterend", html);
    });


  // =============== 2️⃣ 상단 메뉴(menu.html) 불러오기 ===============

  fetch("menu.html")
    .then((res) => res.text())
    .then((html) => {
      const slot = document.querySelector("#nav-slot");
      if (slot) slot.insertAdjacentHTML("afterend", html);

      /*
        상단 메뉴가 실제 DOM에 삽입된 다음에
          - highlightActiveMenu() : 현재 페이지에 해당하는 메뉴를 강조(빨간색)
          - loadSideAndContent()  : 왼쪽 사이드 메뉴 + 본문 내용을 로드
            를 실행해야 합니다.
      */
      highlightActiveMenu();
      loadSideAndContent();
    });


  // =============== 3️⃣ 푸터(footer.html) 불러오기 ===============

  fetch("footer.html")
    .then((res) => res.text())
    .then((html) => {
      const slot = document.querySelector("#footer-slot");

      /*
        insertAdjacentHTML("beforebegin", html)
          - #footer-slot 요소 바로 "앞(beforebegin)"에
            footer.html 내용을 삽입합니다.
          - #footer-slot 은 실제 표시되는 영역이 아니라
            푸터를 삽입하기 위한 마커(표시 위치) 역할만 합니다.
      */
      if (slot) slot.insertAdjacentHTML("beforebegin", html);
    });
});



/* =========================================================
  2. highlightActiveMenu()
    - 현재 보고 있는 페이지에 해당하는 상단 메뉴 <a> 태그에
      "active" 클래스를 붙여서 강조(색 변경)하는 함수입니다.
    - style.css 에서 .navbar a.active { color: red; } 로 지정하면
      활성 메뉴가 빨간색으로 보이게 됩니다.
   ========================================================= */
function highlightActiveMenu() {
  /*
    location.pathname
      예) 주소가 http://example.com/detailillust.html 이라면
          location.pathname 은 "/detailillust.html"

    split("/").pop()
      → "/" 기준으로 나눈 후, 마지막 값만 가져옵니다.
      "/detailillust.html" → "detailillust.html"

    || "index.html"
      → 만약 결과가 빈 문자열("")이면, "index.html" 로 처리합니다.
        (도메인 뒤에 아무것도 없는 경우를 대비)
  */
  const current = location.pathname.split("/").pop() || "index.html";

  /*
    .navbar 안에 있는 모든 <a> 태그를 찾아서
      각각의 href 값과 현재 페이지 파일명을 비교합니다.
  */
  document.querySelectorAll(".navbar a").forEach((a) => {
    const href = a.getAttribute("href"); // 예: "index.html", "webcolor.html" 등

    // 현재 페이지 파일명과 href 가 같다면 active 클래스를 추가
    if (href === current) {
      a.classList.add("active");
    }
  });

  /*
    만약 위에서 active 를 단 링크가 하나도 없다면
    (예: "/" 만 쳐서 들어온 경우),
    기본값으로 index.html 메뉴를 활성화해 줍니다.
  */
  if (!document.querySelector(".navbar a.active")) {
    document
      .querySelectorAll('.navbar a[href="index.html"]')
      .forEach((a) => a.classList.add("active"));
  }
}



/* =========================================================
  3. loadSideAndContent()
  - 상단 메뉴 중에서 활성화된 메뉴(.navbar a.active)를 찾아서
    data-menu 값(예: lectures, webcolor)을 읽은 다음,

      1) menu-데이터값.html  → 왼쪽 사이드 메뉴 (#left-menu)
      2) content-데이터값.html → 본문 영역 (#main-content)

    이렇게 두 가지 파일을 각각 불러와 화면에 넣어주는 함수입니다.
   ========================================================= */
function loadSideAndContent() {
  // 왼쪽 사이드 메뉴가 들어갈 요소
  const leftMenuBox = document.getElementById("left-menu");
  // 본문 내용이 들어갈 요소
  const mainContentBox = document.getElementById("main-content");

  // 둘 중 하나라도 없으면 더 이상 진행하지 않음
  if (!leftMenuBox || !mainContentBox) return;

  // .navbar 안에서 active 클래스가 붙은 링크(현재 메뉴)를 찾기
  const activeLink = document.querySelector(".navbar a.active");
  if (!activeLink) return;

  /*
    data-menu 속성 읽기
    예) <a href="webcolor.html" data-menu="webcolor">WEBCOLOR</a>
        → activeLink.dataset.menu === "webcolor"
  */
  const menuKey = activeLink.dataset.menu;
  if (!menuKey) return;

  /*
    menuKey 를 이용해 파일 이름을 만들어 줍니다.
    예) menuKey = "lectures"
        sideUrl    = "menu-lectures.html"
        contentUrl = "content-lectures.html"
  */
  const sideUrl = `menu-${menuKey}.html`;       // 왼쪽 메뉴 파일
  const contentUrl = `content-${menuKey}.html`; // 본문 내용 파일

  // =============== 3-1) 왼쪽 사이드 메뉴 로드 ===============
  fetch(sideUrl)
    .then((res) => res.text())
    .then((html) => {
      // 받아온 HTML을 왼쪽 메뉴 박스에 그대로 집어넣음
      leftMenuBox.innerHTML = html;
    })
    .catch((err) => {
      console.error("사이드메뉴 로드 실패:", err);
      leftMenuBox.innerHTML = "<p>사이드 메뉴를 불러올 수 없습니다.</p>";
    });

  // =============== 3-2) 본문 내용 로드 ===============
  fetch(contentUrl)
    .then((res) => {
      if (!res.ok) {
        // 파일이 없거나 오류가 있으면 예외 발생
        return Promise.reject("본문 파일이 없습니다.");
      }
      return res.text();
    })
    .then((html) => {
      // 받아온 HTML을 본문 박스에 그대로 삽입
      mainContentBox.innerHTML = html;
    })
    .catch((err) => {
      console.error("본문 로드 실패:", err);
      mainContentBox.innerHTML = "<p>본문 내용을 불러올 수 없습니다.</p>";
    });
}